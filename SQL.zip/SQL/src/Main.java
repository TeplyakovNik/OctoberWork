import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        TableSQL table = new TableSQL(List.of("id", "name"));

        // Вставка данных
        Map<String, Object> row1 = new HashMap<>();
        row1.put("id", 1);
        row1.put("name", "John");
        table.insert(row1);

        Map<String, Object> row2 = new HashMap<>();
        row2.put("id", 2);
        row2.put("name", "Jane");
        table.insert(row2);

        // Обновление данных
        Map<String, Object> updatedRow = new HashMap<>();
        updatedRow.put("id", 2);
        updatedRow.put("name", "Alice");
        table.update(1, updatedRow);

        // Удаление данных
        table.delete(0);

        // Выборка всех данных
        table.selectAll();
    }
}
